package naelanFinal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

public class Naelan {

	public static BufferedReader reader;

	public static void main(String[] args) throws IOException {
		File[] files = null;
		File dir = new File("C:\\Users\\cyura\\Downloads\\TestTechnique\\Fichiers");//pour tester le programme veuillez saisir le bon path du repertoire contenant le fichier

////// comparateur qui nous permet de trier les fichiers en fonction de leur taille///////////

		files = dir.listFiles(new Filtrage());
		Arrays.sort(files, new Comparator<File>() {
			public int compare(File o1, File o2) {
				return (int) (o1.length() - o2.length());
			}
		});
		
///// affichage de fichiers tri�s en fonction du type simplex ou duplex/////////////////////
		
		for (int i = 0; i < files.length; i++) {
			String simplex = "&l0S";
			String duplex1 = "&l1S";
			String duplex2 = "&l2S";
			reader = new BufferedReader(new FileReader(files[i]));

			String line = null;

			while ((line = reader.readLine()) != null) {
				if (line.contains(simplex)) {
					System.out.println("Nom du fichier: " + files[i].getName() + " || La taille du fichier: "
							+ files[i].length() + " Simplex");
				}

				else if (line.contains(duplex1) || line.contains(duplex2)) {
					System.out.println("Nom du fichier: " + files[i].getName() + " || La taille du fichier: "
							+ files[i].length() + " Duplex");
				}
			}

		}

	}

}

///fonction qui permet de choisir seulement les finchiers ayant une extension .pcl//////

class Filtrage implements FilenameFilter {

	public boolean accept(File rep, String fichier) {
		boolean returnValue = false;

		if (fichier.endsWith(".pcl")) {
			returnValue = true;
		}

		return returnValue;
	}

}
